create view mask_columns (attname, attrelid, key_id, key_id_column, associated_columns, nonce_column, format_type) as
SELECT a.attname,
       a.attrelid,
       m.key_id,
       m.key_id_column,
       m.associated_columns,
       m.nonce_column,
       m.format_type
FROM pg_attribute a
         LEFT JOIN pgsodium.masking_rule m ON m.attrelid = a.attrelid AND m.attname = a.attname
WHERE a.attnum > 0
  AND NOT a.attisdropped
ORDER BY a.attnum;

alter table mask_columns
    owner to supabase_admin;

grant delete, insert, references, select, trigger, truncate, update on mask_columns to pgsodium_keyholder;

