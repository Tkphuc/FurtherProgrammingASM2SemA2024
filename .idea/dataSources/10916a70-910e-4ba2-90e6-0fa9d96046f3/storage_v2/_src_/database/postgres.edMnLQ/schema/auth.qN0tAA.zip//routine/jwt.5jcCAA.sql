create function jwt() returns jsonb
    stable
    language sql
as
$$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;

alter function jwt() owner to supabase_auth_admin;

grant execute on function jwt() to postgres;

grant execute on function jwt() to dashboard_user;

