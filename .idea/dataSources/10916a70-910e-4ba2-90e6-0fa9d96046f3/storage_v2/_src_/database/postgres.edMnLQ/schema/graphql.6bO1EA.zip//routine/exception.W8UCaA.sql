create function exception(message text) returns text
    language plpgsql
as
$$
begin
    raise exception using errcode='22000', message=message;
end;
$$;

alter function exception(text) owner to supabase_admin;

grant execute on function exception(text) to postgres;

grant execute on function exception(text) to anon;

grant execute on function exception(text) to authenticated;

grant execute on function exception(text) to service_role;

