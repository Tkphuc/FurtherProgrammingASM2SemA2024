create function channel_name() returns text
    stable
    language sql
as
$$
select nullif(current_setting('realtime.channel_name', true), '')::text;
$$;

alter function channel_name() owner to supabase_realtime_admin;

grant execute on function channel_name() to postgres;

grant execute on function channel_name() to dashboard_user;

