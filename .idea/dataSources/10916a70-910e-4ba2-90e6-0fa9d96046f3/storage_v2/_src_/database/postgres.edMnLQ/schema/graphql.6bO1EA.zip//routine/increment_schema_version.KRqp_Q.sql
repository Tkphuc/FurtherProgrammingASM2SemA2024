create function increment_schema_version() returns event_trigger
    security definer
    language plpgsql
as
$$
begin
    perform nextval('graphql.seq_schema_version');
end;
$$;

alter function increment_schema_version() owner to supabase_admin;

grant execute on function increment_schema_version() to postgres;

grant execute on function increment_schema_version() to anon;

grant execute on function increment_schema_version() to authenticated;

grant execute on function increment_schema_version() to service_role;

