create function role() returns text
    stable
    language sql
as
$$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;

comment on function role() is 'Deprecated. Use auth.jwt() -> ''role'' instead.';

alter function role() owner to supabase_auth_admin;

grant execute on function role() to dashboard_user;

