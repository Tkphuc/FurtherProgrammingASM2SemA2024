create function quote_wal2json(entity regclass) returns text
    immutable
    strict
    language sql
as
$$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;

alter function quote_wal2json(regclass) owner to supabase_admin;

grant execute on function quote_wal2json(regclass) to postgres;

grant execute on function quote_wal2json(regclass) to anon;

grant execute on function quote_wal2json(regclass) to authenticated;

grant execute on function quote_wal2json(regclass) to service_role;

grant execute on function quote_wal2json(regclass) to dashboard_user;

grant execute on function quote_wal2json(regclass) to supabase_realtime_admin;

