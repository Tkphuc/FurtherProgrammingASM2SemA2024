create function filename(name text) returns text
    language plpgsql
as
$$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;

alter function filename(text) owner to supabase_storage_admin;

