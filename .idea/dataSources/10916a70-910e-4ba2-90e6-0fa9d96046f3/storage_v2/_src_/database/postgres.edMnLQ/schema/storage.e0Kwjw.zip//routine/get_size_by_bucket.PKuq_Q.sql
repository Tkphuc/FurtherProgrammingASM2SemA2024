create function get_size_by_bucket()
    returns TABLE(size bigint, bucket_id text)
    language plpgsql
as
$$
BEGIN
    return query
        select sum((metadata->>'size')::int) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;

alter function get_size_by_bucket() owner to supabase_storage_admin;

