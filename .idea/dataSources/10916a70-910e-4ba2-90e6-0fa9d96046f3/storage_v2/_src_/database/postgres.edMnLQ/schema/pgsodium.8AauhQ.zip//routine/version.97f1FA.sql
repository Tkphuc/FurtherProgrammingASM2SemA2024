create function version() returns text
    language sql
as
$$ SELECT extversion FROM pg_extension WHERE extname = 'pgsodium' $$;

alter function version() owner to supabase_admin;

