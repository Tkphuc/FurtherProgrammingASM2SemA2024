create function get_schema_version() returns integer
    security definer
    language sql
as
$$
    select last_value from graphql.seq_schema_version;
$$;

alter function get_schema_version() owner to supabase_admin;

grant execute on function get_schema_version() to postgres;

grant execute on function get_schema_version() to anon;

grant execute on function get_schema_version() to authenticated;

grant execute on function get_schema_version() to service_role;

